from game import *


import collections
import torch.nn as nn
import torch
import cv2

###  check proccesed image is coherent

class time_step():
    def __init__(self):
        self.observation_before_action = []
        self.observation_after_action = []
        self.action = []
        self.reward = []


class experience():
    def __init__(self , observation_before_action , observation_after_action, action, reward , game_num, frame_num , game_finished):
        self.observation_before_action = observation_before_action
        self.observation_after_action = observation_after_action
        self.action = action
        self.reward = reward
        self.game_num = game_num
        self.frame_num = frame_num
        self.game_finished = game_finished


class DuelCNN(nn.Module):
    def __init__(self, output_size: int):
        super(DuelCNN, self).__init__()
        # Representation layers
        
        self.representation = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=32, kernel_size=8, stride=4),
            nn.BatchNorm2d(32),
            nn.Conv2d(in_channels=32, out_channels=24, kernel_size=4, stride=2),
            nn.Conv2d(in_channels=24, out_channels=24, kernel_size=4, stride=2),
            nn.BatchNorm2d(24),
            nn.Conv2d(in_channels=24, out_channels=8, kernel_size=2, stride=1),
            nn.BatchNorm2d(8),
        )

        # Action layer
        self.Alinear1 = nn.Linear(in_features=16, out_features=80)
        self.Alrelu = nn.LeakyReLU()  # Linear 1 activation funct
        self.Alinear2 = nn.Linear(in_features=80, out_features=output_size)

        # State Value layer
        self.Vlinear1 = nn.Linear(in_features=16, out_features=80)
        self.Vlrelu = nn.LeakyReLU()  # Linear 1 activation funct
        self.Vlinear2 = nn.Linear(in_features=80, out_features=1)  # Only 1 node

    def forward(self, x) -> float:
        x = self.representation(x)
        x = x.view(x.size(0), -1)  # Flatten every batch
        Ax = self.Alrelu(self.Alinear1(x))
        Ax = self.Alinear2(Ax)  # No activation on last layer
        Vx = self.Vlrelu(self.Vlinear1(x))
        Vx = self.Vlinear2(Vx)  # No activation on last layer
        q = Vx + (Ax - Ax.mean())
        return q

    def show_model_info(self):
        """Displays the parameters and shapes of the network layers"""
        torchsummary.summary(self, (4, 64, 80))


class agent():
    def __init__(self ):

        self.minimum_memory = 1000# dont train until here

        self.proccessed_image_width = 64
        self.proccessed_image_height = 80

        self.action_size = 4 # left right jump stay
        # Discount rate for future predictions
        self.gamma = 0.97
        self.alpha = 0.00025

        # Adaptive Epsilon Decay Rate for decaying exploration rates
        self.epsilon = 1  # Explore or Exploit
        self.epsilon_decay = 0.99
        self.epsilon_minimum = 0.05  # Minimum for Explore

        # Deque holds replay mem.
        self.memory = collections.deque(maxlen=50000)
        self.online_model = DuelCNN(output_size=self.action_size).to('cpu') # to get q value of states
        self.target_model = DuelCNN(output_size=self.action_size).to('cpu') # to get target q value of states

        self.optimizer = torch.optim.Adam(self.online_model.parameters(), lr=self.alpha)

    def storeResults(self, state, action, reward, nextState, done):
        """
        Store every result to memory
        """
        self.memory.append([state[None, :], action, reward, nextState[None, :], done])

    def process_image(self, image):

        image = cv2.cvtColor(image , cv2.COLOR_RGB2BGR)

 #      image = cv2.cvtColor(image , cv2.COLOR_BGR2RGB)
  
        image = cv2.cvtColor(image , cv2.COLOR_BGR2GRAY)
        
        frame = cv2.resize(image, (self.proccessed_image_width, self.proccessed_image_height))  # Resize

 #      frame = frame.reshape(self.proccessed_image_width, self.proccessed_image_height) / 255

        return frame



    def train(self):

        # get mini batch

        state, action, reward, next_state, done = zip(*random.sample(self.memory, 64))

        state = torch.tensor(np.concatenate(state), dtype=torch.float32, device="cpu")

        next_state = torch.tensor(np.concatenate(next_state), dtype=torch.float32, device="cpu")
        action = torch.tensor(action, dtype=torch.long, device="cpu")
        reward = torch.tensor(reward, dtype=torch.float32, device="cpu")
        done = torch.tensor(done, dtype=torch.float32, device="cpu")

        # Make predictions      # nn.Module

        state_q_values = self.online_model(state)
        next_states_q_values = self.online_model(next_state)
        next_states_target_q_values = self.target_model(next_state)

        # Find selected action's q_value
        selected_q_value = state_q_values.gather(1, action.unsqueeze(1)).squeeze(1)
        # Get indice of the max value of next_states_q_values
        # Use that indice to get a q_value from next_states_target_q_values
        # We use greedy for policy So it called off-policy
        next_states_target_q_value = next_states_target_q_values.gather(1, next_states_q_values.max(1)[1].unsqueeze(1)).squeeze(1)
        # Use Bellman function to find expected q value
        expected_q_value = reward + self.gamma * next_states_target_q_value * (1 - done)
     #   print(selected_q_value)
      #  print(expected_q_value)
       # Calc loss with expected_q_value and q_value


        loss = (selected_q_value - expected_q_value.detach()).pow(2).mean()
        A = """
        print(loss)
        print(selected_q_value)
        print(expected_q_value)
        if loss != 0:
            print(6/0)

        print(3/0)
        """

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return loss, torch.max(state_q_values).item()

    def act(self, state):

        if random.uniform(0, 1) <= self.epsilon:
            action = random.randrange(self.action_size)
    #        print(str(action)+"  =      action      random ")
        else:
            with torch.no_grad():
    #            print(state)
    #            print(state.shape)
                state = torch.tensor(state, dtype=torch.float32, device="cpu")
    #            print("    ###############    7777777777777   ############  ")
    #            print(str(state)+"  =  state")
        #        print(state.shape)
       #         print(state.size())
    #            print(str(state.unsqueeze(0))+"  =  state.unsqueeze(0)")
                q_values = self.online_model.forward(state.unsqueeze(0))
                action = torch.argmax(q_values).item()
    #            print(str(action)+"  =      action      chosen ")
        return action


thegame = game()
agent = agent()
game_num = 0

frame_num = 0

observation, reward =  thegame.play_frame(frame_num , "nothing")

#experience_storer = experience_storer()
# agent()
this_games_experiences = []

#  experience():
# (self , observation_before_action , observation_after_action, action, reward)



screwmine = """

while (game_num < number_of_games_to_train):

    if frame_num > 1:
        last_observation = observation
    action = agent.act( observation )# self.epsilon
    observation, reward = thegame.play_frame(frame_num, action)
    observation = agent.process_image(observation)
    observation = np.stack((observation , observation , observation , observation))
#    print(str(observation)+" =  observation  ")

    if frame_num > 1:
        game_over = False
        if reward == -1000:
            game_over = True
        this_games_experiences.append([last_observation, observation , action, reward , game_num, frame_num , game_over])

    this_games_rewards += reward

    if reward == -1000:
        if game_num % number_of_games_until_epsilon_change == 0:
            print("a multiple of "+str(number_of_games_until_epsilon_change))
            if agent.epsilon > 0:
                agent.epsilon += (-0.01)

        print(str(game_num)+" =  game_num        ,    agent.epsilon  = "+str(agent.epsilon))
        thegame.reset()
        game_num+= 1
        if frame_num > 1:
            agent.add_games_worth_of_experiences(this_games_experiences)
        #print(experience_storer.experiences)

        all_game_rewards += this_games_rewards
        this_games_experiences = []
        frame_num = -1
        this_games_rewards = 0
        average_rewards.append(all_game_rewards / game_num)
    if len(agent.memory) < agent.minimum_memory:
        loss, max_q = [0, 0]
    else:
        print("train")
        loss, max_q = agent.train()
    this_games_rewards
    frame_num+= 1

"""


game_num = 1
all_game_rewards = 0
this_games_rewards = 0
average_rewards = []

min_memory = 1000
total_step = 0
max_steps =  50000
training_results = []
losses = []
number_of_games_to_train = 200
import time

for episode in range(1 ,number_of_games_to_train):
    print(len(agent.memory))
    startTime = time.time()  # Keep time
    state, reward = thegame.reset()  # Reset env

    #observation = agent.process_image(observation)
   # state = state[0]
#    print(state)
 #   print(type(state))
  #  print(9/0)

    state = agent.process_image(state)  # Process image


    # Stack state . Every state contains 4 time contionusly frames
    # We stack frames like 4 channel image
    state = np.stack((state , state, state, state))


    total_max_q_val = 0  # Total max q vals
    total_reward = 0  # Total reward for each episode
    total_loss = 0  # Total loss for each episode
    for step in range(max_steps):

        # Select and perform an action

        action = agent.act(state)  # Act

        next_state, reward = thegame.play_frame(frame_num, action)
    #    next_state, reward= environment.step(action)  # Observe

        if reward == -1000:
            done = True
        else:
            done = False

        next_state = agent.process_image(next_state)  # Process image

        # Stack state . Every state contains 4 time contionusly frames
        # We stack frames like 4 channel image
        next_state = np.stack((next_state, state[0], state[1], state[2]))

        # Store the transition in memory
        agent.storeResults(state, action, reward, next_state, done)  # Store to mem

        # Move to the next state
        state = next_state  # Update state


        # Perform one step of the optimization (on the target network)
        if len(agent.memory) < min_memory:
            loss, max_q = [0, 0]
        else:
            # Train with random state from memory
            loss, max_q = agent.train()

        total_loss += loss
        total_max_q_val += max_q
        total_reward += reward
        total_step += 1
      #  print(total_step)
        if total_step % 5000 == 0:
            print("yaaaaaaaaaaay")
            if agent.epsilon > 0:
                agent.epsilon += (-0.01)


        if done:
            # Episode completed
            ep_results = [
                episode,
                total_reward,
                total_loss,
                agent.epsilon,
                time.time() - startTime,
            ]
            training_results.append(ep_results)
            print(
                f"Episode:{ep_results[0]} Reward:{ep_results[1]} Loss:{ep_results[2]} Epsilon:{ep_results[3]} Duration:{ep_results[4]}"
            )
            losses.append(ep_results[2])
            average_rewards.append(total_reward / episode)
            poo = """ if SAVE_MODELS:
                if episode % int(config["SAVING"]["interval"]) == 0:
                    # TODO change to save checkpoints instead of overriting
                    torch.save(
                        agent.online_model.state_dict(), f"{MODEL_PATH}/model.pkl"
                    )

                    with open(f"{MODEL_PATH}/parameters.json", "w") as outfile:
                        json.dump(
                            {
                                "epsilon": agent.epsilon,
                                "configuration": {
                                    sect: dict(config.items(sect))
                                    for sect in config.sections()
                                },
                            },
                            outfile,
                        )

                if episode == int(config["TRAINING"]["max_episode"]) - 1:
                    with open(f"{MODEL_PATH}/training_logs.txt", "w") as resultfile:
                        np.savetxt(resultfile, np.array(training_results))
                   """
            #if TRAIN_MODEL:
                # update target model
            agent.target_model.load_state_dict(agent.online_model.state_dict())
            break


import matplotlib.pyplot as plt
plt.plot(range(len(average_rewards)) , average_rewards)
plt.ylabel('average rewards')
plt.savefig('average rewards.pdf')
plt.clf()
plt.plot(range(len(losses)) , losses)
plt.ylabel('losses')
plt.savefig('losses.pdf')
plt.show()

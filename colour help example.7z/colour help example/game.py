import pygame
import math
import numpy as np
import random
import copy
import time

pygame.init()
#pygame.font.init()

black = (0,0,0)
white = (255,255,255)
red = (200,0,0)
green = (0,200,0)
blue = (0,0,255)
grey=(169,169,169)
yellow = (246, 240, 55)





class enemy():
    def __init__(self, floor):
        self.x = -150
        self.width= random.randint(10,100)
        self.height= random.randint(10,100)
        self.y = floor-self.height
        self.speed= random.randint(4,11)
    def move(self, x, y , width, height):
        self.x += self.speed
        if self.x+self.width > x and x > self.x:
            if self.y < y+height:# and y+height > self.y :
                return True
        return False


class edge():
    def __init__(self, x=False , y=False):
        self.x = x
        self.y = y
        self.width = 10
    def hit_detection(self , x,y,width,height):
        if type(self.y) == type(True):
            if self.x > 50:
                if self.x<x+width:
                    return True
            else:
                if x<self.x+self.width:
                    return True
        return False



class game():
    def __init__(self):
        self.screen_width = 800
        self.screen_height = 800
        self.x = 300
        self.floor = 500
        self.height= 60
        self.y = self.floor-self.height
        self.y_speed = 0
        self.x_speed = 0
        self.enemies = []
        self.jump_speed = -21
        self.move_speed = 0.5
        self.gravity = 0.981
        self.width= 30

        self.enemies_dodge = 0
        self.display = pygame.display.set_mode((800,800))
        pygame.display.set_caption(' dodge ')
        self.clock = pygame.time.Clock()
        self.edges = [edge(0), edge(790)]

    def reset(self):
        self.x = 300
        self.y = self.floor-self.height
        self.y_speed = 0
        self.x_speed = 0
        self.enemies = []
        self.draw()
        rect = pygame.Rect(0,0,self.screen_width,self.screen_height) # size of our screenshot
        observation = self.display.subsurface(rect) ## the screenhot
        observation = pygame.surfarray.array3d(observation)
        return observation, 0   #### observation /  reward
    def on_floor(self):
#        print(str(self.y)+" + "+str(self.height)+" - "+str(self.floor))
        if abs((self.y + self.height) - self.floor) < 1:
 #           print("on floor")
            return True
  #      print("not on floor")
        return False

    def below_floor(self):
   #     print(str(self.y)+" + "+str(self.height)+" - "+str(self.floor))
        if (self.y + self.height) - self.floor > 0:
    #        print("below floor")
            return True
     #   print("not below floor")
        return False

    def handle_player_movement(self, action):

      #  print((self.y +self.height)- self.floor)
        if self.on_floor():
            if action == 0: # do nothing
                pass
            elif action == 'left' or action == 1 : # left
                self.x_speed += (- self.move_speed)
            elif action == 'right' or action == 2: # right
                self.x_speed += ( self.move_speed)
            elif action == 'jump' or action == 3: # jump
#                print("a")
                if self.on_floor():
 #                   print("b")
                    self.y+= 2
                    self.y_speed += ( self.jump_speed)
                else:
                    pass
  #                  print("not on floor")

        self.x += self.x_speed

        if not (self.on_floor() and self.below_floor()):
#            print("in air")
 #           print(self.y)
            self.y += self.y_speed
            self.y_speed += self.gravity
        if self.below_floor():
            self.y = self.floor-self.height
            self.y_speed = 0



    def handle_enemies_movement(self):
        any_collision = False
        for e in self.enemies:
            collision = e.move(self.x, self.y, self.width, self.height)
            if collision:
                any_collision = True
        return any_collision
    def handle_enemies_spawning(self):
        chooser = random.randint(0,400)
        if chooser == 67:
            if len(self.enemies)<4:
                self.enemies.append(enemy(self.floor))


    def keyboard_handle(self):
        action = 0
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    action = 1
                if event.key == pygame.K_RIGHT:
                    action = 2
                if event.key == pygame.K_UP:
       #             print("up")
                    action = 3
      #  print(str(action)+"   action   ")
        return action

    def handle_edges(self):
        for ed in self.edges:
            hit = ed.hit_detection(self.x , self.y, self.width, self.height)
            if hit:
                return True
        enemies_to_remove = []
        for e in self.enemies:
            right_edge = self.edges[1]
            if e.x > right_edge.x:
                enemies_to_remove.append(e)
        for e in enemies_to_remove:
            self.enemies.remove(e)
        return False

    def play_frame(self, num , action):
        self.handle_player_movement(action)
        self.handle_enemies_spawning()
        hit = self.handle_edges()

        if not hit:
            hit = self.handle_enemies_movement()
        self.draw()

        rect = pygame.Rect(0,0,self.screen_width,self.screen_height) # size of our screenshot
        observation = self.display.subsurface(rect) ## the screenhot
        observation = pygame.surfarray.array3d(observation)
    #    proccessed_observation =
        if hit:
            return observation, -1000   #### observation /  reward
        return observation, 1   #### observation /  reward


    def draw(self):
        self.display.fill(white)
        for ed in self.edges:
            pygame.draw.rect(self.display, red,[ed.x, -40, ed.width, 1500])
        for e in self.enemies:
            pygame.draw.rect(self.display, red,[e.x, e.y, e.width, e.height])
        pygame.draw.rect(self.display, black,[-1, self.floor,2500, 5])
        pygame.draw.rect(self.display, green,[self.x, self.y , self.width, self.height])
        pygame.display.update()
